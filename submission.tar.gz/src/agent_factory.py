from .base_agent import BaseAgent
from .random_agent import RandomAgent
from .evolutionary.evolutionary_agent import EvolutionaryAgent

def get_agent(agent_type: str = "random", **kwargs) -> BaseAgent:
    """
    指定されたタイプのエージェントインスタンスを作成して返します。
    これにより、アルゴリズムやアプローチの変更が容易になります。
    """
    if agent_type == "random":
        return RandomAgent(**kwargs)
    elif agent_type == "evolutionary":
        return EvolutionaryAgent(**kwargs)
    else:
        raise ValueError(f"未知のエージェントタイプ: {agent_type}")
