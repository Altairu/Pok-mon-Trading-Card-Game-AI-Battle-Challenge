import random
from cg.api import Observation

# 評価関数の重みのデフォルト値
# 1. 自分の取得サイド数 (多いほど良い)
# 2. 相手の取得サイド数 (少ないほど良い)
# 3. 自分の場のポケモン数 (展開できているほど良い)
# 4. 相手の場のポケモン数 (少ないほど良い)
# 5. 自分の場の総HP (高いほど良い)
# 6. 相手の場の総HP (低いほど良い)
# 7. 自分の場の総エネルギー数 (多いほど良い)
# 8. 相手の場の総エネルギー数 (少ないほど良い)
# 9. 自分の手札枚数 (選択肢が多いほど良い)
# 10. 自分のトラッシュ枚数 (リソース活用)
DEFAULT_WEIGHTS = [
    100.0,
    -100.0,
    5.0,
    -5.0,
    0.5,
    -0.5,
    10.0,
    -5.0,
    2.0,
    0.1
]

def get_features(obs: Observation) -> list[float]:
    """
    Observation から盤面特徴量ベクトルを抽出します。
    """
    if obs is None or obs.current is None:
        return [0.0] * 10
        
    state = obs.current
    your_idx = state.yourIndex
    opp_idx = 1 - your_idx
    
    me = state.players[your_idx]
    opp = state.players[opp_idx]
    
    # 1. 自分の取ったサイド枚数
    my_prizes_taken = 6 - len(me.prize)
    # 2. 相手の取ったサイド枚数
    opp_prizes_taken = 6 - len(opp.prize)
    
    # ポケモンの統計値を取得するインナークラス/関数
    def get_pokemon_stats(active_list: list, bench_list: list):
        count = 0
        total_hp = 0
        total_energy = 0
        
        # バトル場
        for p in active_list:
            if p is not None:
                count += 1
                total_hp += p.hp
                total_energy += len(p.energies)
                
        # ベンチ
        for p in bench_list:
            if p is not None:
                count += 1
                total_hp += p.hp
                total_energy += len(p.energies)
                
        return count, total_hp, total_energy

    my_count, my_hp, my_energy = get_pokemon_stats(me.active, me.bench)
    opp_count, opp_hp, opp_energy = get_pokemon_stats(opp.active, opp.bench)
    
    # 9. 自分の手札枚数
    my_hand_count = me.handCount if me.hand is None else len(me.hand)
    # 10. 自分のトラッシュ枚数
    my_discard_count = len(me.discard)
    
    return [
        float(my_prizes_taken),
        float(opp_prizes_taken),
        float(my_count),
        float(opp_count),
        float(my_hp),
        float(opp_hp),
        float(my_energy),
        float(opp_energy),
        float(my_hand_count),
        float(my_discard_count)
    ]

def evaluate_state(obs: Observation, weights: list[float]) -> float:
    """
    指定された重みパラメータを用いて、現在の盤面状態の評価スコアを算出します。
    """
    features = get_features(obs)
    return sum(f * w for f, w in zip(features, weights))

def run_genetic_algorithm(obs: Observation) -> list[int] | None:
    """
    進化計算エージェントが各アクションを選択するためのインターフェース。
    通常、Kaggle提出時には学習済みのデフォルト重みを使用して、
    1ステップ先の状態評価を行います（探索処理は agent 側で実行）。
    """
    # 探索の実際の決定ロジックは evolutionary_agent.py が呼び出すため、
    # ここでは重みパラメータを提供する役割とします。
    return None

# ==========================================
# ローカル環境用: 遺伝的アルゴリズムの最適化ループ
# ==========================================

GENE_SIZE = 10
POPULATION_SIZE = 20
GENERATIONS = 5
MUTATION_RATE = 0.1
MUTATION_SCALE = 5.0

def evaluate_weights(weights: list[float]) -> float:
    """
    ローカル学習用：個体（重みベクトル）の適合度を評価します。
    ※ プレースホルダーとして、デフォルト重みとの適合度を返します。
    """
    diff = sum((w - d)**2 for w, d in zip(weights, DEFAULT_WEIGHTS))
    return 1.0 / (1.0 + diff)

def crossover(parent1: list[float], parent2: list[float]) -> list[float]:
    """二点交叉を行います。"""
    child = []
    pt1 = random.randint(0, GENE_SIZE - 2)
    pt2 = random.randint(pt1 + 1, GENE_SIZE - 1)
    for i in range(GENE_SIZE):
        if i < pt1 or i > pt2:
            child.append(parent1[i])
        else:
            child.append(parent2[i])
    return child

def mutate(weights: list[float]) -> list[float]:
    """突然変異を行います。"""
    mutated = []
    for w in weights:
        if random.random() < MUTATION_RATE:
            mutated.append(w + random.gauss(0, MUTATION_SCALE))
        else:
            mutated.append(w)
    return mutated

def train_ga() -> list[float]:
    """
    ローカルで遺伝的アルゴリズムを実行し、最適な重みパラメータを探索します。
    """
    print("遺伝的アルゴリズム（GA）による重み最適化を開始します...")
    
    # 初期世代の生成（デフォルト値をベースに揺らぎを与える）
    population = []
    for _ in range(POPULATION_SIZE):
        ind = [w + random.gauss(0, 10.0) for w in DEFAULT_WEIGHTS]
        population.append(ind)
        
    for gen in range(GENERATIONS):
        scores = [evaluate_weights(ind) for ind in population]
        
        # 最良個体の特定
        best_score = -float('inf')
        best_idx = 0
        for idx, score in enumerate(scores):
            if score > best_score:
                best_score = score
                best_idx = idx
                
        print(f"世代 {gen+1}/{GENERATIONS} | 最良適合度: {best_score:.6f}")
        
        new_population = [population[best_idx]]  # エリート保存
        
        while len(new_population) < POPULATION_SIZE:
            # トーナメント選択 (サイズ 3)
            candidates = random.sample(list(zip(population, scores)), 3)
            parent1 = max(candidates, key=lambda x: x[1])[0]
            
            candidates = random.sample(list(zip(population, scores)), 3)
            parent2 = max(candidates, key=lambda x: x[1])[0]
            
            child = crossover(parent1, parent2)
            child = mutate(child)
            new_population.append(child)
            
        population = new_population
        
    # 最終的な最良個体を特定
    final_scores = [evaluate_weights(ind) for ind in population]
    best_score = -float('inf')
    best_idx = 0
    for idx, score in enumerate(final_scores):
        if score > best_score:
            best_score = score
            best_idx = idx
            
    print("GA最適化が完了しました。")
    return population[best_idx]
